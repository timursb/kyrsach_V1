using System;
using System.Windows.Forms;

namespace RestaurantAppV1.Forms
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnMenu_Click(object sender, EventArgs e)
        {
            using (var form = new MenuForm())
            {
                form.ShowDialog(this);
            }
        }

        private void btnEvents_Click(object sender, EventArgs e)
        {
            using (var form = new EventsForm())
            {
                form.ShowDialog(this);
            }
        }
    }
}

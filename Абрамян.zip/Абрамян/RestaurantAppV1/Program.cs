using System;
using System.Windows.Forms;
using RestaurantAppV1.Forms;

namespace RestaurantAppV1
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}

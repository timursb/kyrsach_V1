namespace RestaurantAppV1
{
    public class PreorderLine
    {
        public int DishId { get; set; }
        public string DishName { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }

        public decimal LineTotal => Quantity * Price;
    }
}

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;

namespace RestaurantAppV1
{
    public static class ReservationHelper
    {
        private static string GetUserForeignKeyColumn()
        {
            var columns = Db.GetColumns("Reservations");
            if (columns.Contains("UserID"))
            {
                return "UserID";
            }

            if (columns.Contains("CustomerID"))
            {
                return "CustomerID";
            }

            throw new InvalidOperationException(
                "В таблице Reservations нет поля UserID или CustomerID.");
        }

        public static void ValidateSchema()
        {
            var reservationColumns = Db.GetColumns("Reservations");
            var itemColumns = Db.GetColumns("ReservationItems");

            RequireColumn(reservationColumns, "Reservations", "ReservationID");
            RequireColumn(reservationColumns, "Reservations", GetUserForeignKeyColumn());
            RequireColumn(reservationColumns, "Reservations", "TableID");
            RequireColumn(reservationColumns, "Reservations", "ReservationDateTime");
            RequireColumn(reservationColumns, "Reservations", "PersonsCount");
            RequireColumn(reservationColumns, "Reservations", "Status");

            RequireColumn(itemColumns, "ReservationItems", "ReservationID");
            RequireColumn(itemColumns, "ReservationItems", "DishID");
            RequireColumn(itemColumns, "ReservationItems", "Quantity");
            RequireColumn(itemColumns, "ReservationItems", "PriceAtOrder");
        }

        private static void RequireColumn(HashSet<string> columns, string tableName, string columnName)
        {
            if (!columns.Contains(columnName))
            {
                throw new InvalidOperationException(
                    string.Format("В таблице {0} отсутствует поле {1}.", tableName, columnName));
            }
        }

        public static DataTable GetAllReservations()
        {
            var userColumn = GetUserForeignKeyColumn();

            var table = Db.Query(
                "SELECT r.ReservationID, u.FullName AS [Клиент], t.TableNumber AS [Стол], " +
                "r.ReservationDateTime AS [Дата и время], r.PersonsCount AS [Гостей], r.[Status] AS [Статус] " +
                "FROM ([Reservations] AS r INNER JOIN [Users] AS u ON r." + userColumn + " = u.UserID) " +
                "INNER JOIN [Tables] AS t ON r.TableID = t.TableID " +
                "ORDER BY r.ReservationDateTime DESC");

            AppendTotalColumn(table);
            return table;
        }

        public static DataTable GetUserReservations(int userId)
        {
            var userColumn = GetUserForeignKeyColumn();

            var table = Db.Query(
                "SELECT r.ReservationID, t.TableNumber AS [Стол], " +
                "r.ReservationDateTime AS [Дата и время], r.PersonsCount AS [Гостей], r.[Status] AS [Статус] " +
                "FROM [Reservations] AS r INNER JOIN [Tables] AS t ON r.TableID = t.TableID " +
                "WHERE r." + userColumn + " = ? ORDER BY r.ReservationDateTime DESC",
                new OleDbParameter { OleDbType = OleDbType.Integer, Value = userId });

            AppendTotalColumn(table);
            return table;
        }

        private static void AppendTotalColumn(DataTable table)
        {
            table.Columns.Add("Сумма предзаказа", typeof(decimal));

            foreach (DataRow row in table.Rows)
            {
                var reservationId = Convert.ToInt32(row["ReservationID"]);
                row["Сумма предзаказа"] = GetReservationTotal(reservationId);
            }
        }

        public static DataTable GetReservationItems(int reservationId)
        {
            return Db.Query(
                "SELECT d.[Name] AS [Блюдо], ri.Quantity AS [Кол-во], ri.PriceAtOrder AS [Цена], " +
                "(ri.Quantity * ri.PriceAtOrder) AS [Сумма] " +
                "FROM ([ReservationItems] AS ri INNER JOIN [Dishes] AS d ON ri.DishID = d.DishID) " +
                "WHERE ri.ReservationID = ?",
                new OleDbParameter { OleDbType = OleDbType.Integer, Value = reservationId });
        }

        public static decimal GetReservationTotal(int reservationId)
        {
            var value = Db.Scalar(
                "SELECT Sum(Quantity * PriceAtOrder) FROM [ReservationItems] WHERE ReservationID = ?",
                new OleDbParameter { OleDbType = OleDbType.Integer, Value = reservationId });

            if (value == null || value == DBNull.Value)
            {
                return 0m;
            }

            return Convert.ToDecimal(value);
        }

        public static int CreateReservation(
            int userId,
            int tableId,
            DateTime reservationDateTime,
            int personsCount,
            IEnumerable<PreorderLine> items)
        {
            ValidateSchema();

            var userColumn = GetUserForeignKeyColumn();
            var itemList = items.ToList();

            using (var connection = new OleDbConnection(Db.ConnectionString))
            {
                connection.Open();
                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        var insertReservationSql = string.Format(
                            "INSERT INTO [Reservations] ([{0}], [TableID], [ReservationDateTime], [PersonsCount], [Status]) VALUES (?, ?, ?, ?, ?)",
                            userColumn);

                        using (var command = new OleDbCommand(insertReservationSql, connection, transaction))
                        {
                            command.Parameters.Add(CreateParameter(OleDbType.Integer, userId));
                            command.Parameters.Add(CreateParameter(OleDbType.Integer, tableId));
                            command.Parameters.Add(CreateDateParameter(reservationDateTime));
                            command.Parameters.Add(CreateParameter(OleDbType.Integer, personsCount));
                            command.Parameters.Add(CreateParameter(OleDbType.VarWChar, "Новая"));
                            command.ExecuteNonQuery();
                        }

                        int reservationId;
                        using (var command = new OleDbCommand("SELECT @@IDENTITY", connection, transaction))
                        {
                            reservationId = Convert.ToInt32(command.ExecuteScalar());
                        }

                        foreach (var item in itemList)
                        {
                            using (var command = new OleDbCommand(
                                "INSERT INTO [ReservationItems] ([ReservationID], [DishID], [Quantity], [PriceAtOrder]) VALUES (?, ?, ?, ?)",
                                connection,
                                transaction))
                            {
                                command.Parameters.Add(CreateParameter(OleDbType.Integer, reservationId));
                                command.Parameters.Add(CreateParameter(OleDbType.Integer, item.DishId));
                                command.Parameters.Add(CreateParameter(OleDbType.Integer, item.Quantity));
                                command.Parameters.Add(CreateParameter(OleDbType.Decimal, item.Price));
                                command.ExecuteNonQuery();
                            }
                        }

                        transaction.Commit();
                        return reservationId;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw new InvalidOperationException("Не удалось сохранить бронь: " + GetFullMessage(ex), ex);
                    }
                }
            }
        }

        public static void UpdateStatus(int reservationId, string status)
        {
            Db.Execute(
                "UPDATE [Reservations] SET [Status] = ? WHERE ReservationID = ?",
                new OleDbParameter { OleDbType = OleDbType.VarWChar, Value = status },
                new OleDbParameter { OleDbType = OleDbType.Integer, Value = reservationId });
        }

        public static void DeleteReservation(int reservationId)
        {
            using (var connection = new OleDbConnection(Db.ConnectionString))
            {
                connection.Open();
                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        using (var command = new OleDbCommand(
                            "DELETE FROM [ReservationItems] WHERE ReservationID = ?",
                            connection,
                            transaction))
                        {
                            command.Parameters.Add(CreateParameter(OleDbType.Integer, reservationId));
                            command.ExecuteNonQuery();
                        }

                        using (var command = new OleDbCommand(
                            "DELETE FROM [Reservations] WHERE ReservationID = ?",
                            connection,
                            transaction))
                        {
                            command.Parameters.Add(CreateParameter(OleDbType.Integer, reservationId));
                            command.ExecuteNonQuery();
                        }

                        transaction.Commit();
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }

        private static OleDbParameter CreateParameter(OleDbType type, object value)
        {
            return new OleDbParameter { OleDbType = type, Value = value ?? DBNull.Value };
        }

        private static OleDbParameter CreateDateParameter(DateTime value)
        {
            return new OleDbParameter
            {
                OleDbType = OleDbType.Date,
                Value = value
            };
        }

        private static string GetFullMessage(Exception ex)
        {
            var builder = new StringBuilder(ex.Message);
            if (ex.InnerException != null)
            {
                builder.Append(" ").Append(ex.InnerException.Message);
            }

            return builder.ToString();
        }
    }
}

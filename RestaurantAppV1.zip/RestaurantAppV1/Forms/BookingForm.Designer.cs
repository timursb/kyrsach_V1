namespace RestaurantAppV1.Forms
{
    partial class BookingForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblTable = new System.Windows.Forms.Label();
            this.lblDateTime = new System.Windows.Forms.Label();
            this.lblPersons = new System.Windows.Forms.Label();
            this.cmbTable = new System.Windows.Forms.ComboBox();
            this.dtpDateTime = new System.Windows.Forms.DateTimePicker();
            this.numPersons = new System.Windows.Forms.NumericUpDown();
            this.grpPreorder = new System.Windows.Forms.GroupBox();
            this.lblDish = new System.Windows.Forms.Label();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.cmbDish = new System.Windows.Forms.ComboBox();
            this.numQuantity = new System.Windows.Forms.NumericUpDown();
            this.btnAddDish = new System.Windows.Forms.Button();
            this.btnRemoveDish = new System.Windows.Forms.Button();
            this.gridPreorder = new System.Windows.Forms.DataGridView();
            this.lblTotal = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numPersons)).BeginInit();
            this.grpPreorder.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numQuantity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridPreorder)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(12, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(206, 25);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Бронирование стола";
            // 
            // lblTable
            // 
            this.lblTable.AutoSize = true;
            this.lblTable.Location = new System.Drawing.Point(14, 48);
            this.lblTable.Name = "lblTable";
            this.lblTable.Size = new System.Drawing.Size(35, 15);
            this.lblTable.TabIndex = 1;
            this.lblTable.Text = "Стол:";
            // 
            // lblDateTime
            // 
            this.lblDateTime.AutoSize = true;
            this.lblDateTime.Location = new System.Drawing.Point(14, 78);
            this.lblDateTime.Name = "lblDateTime";
            this.lblDateTime.Size = new System.Drawing.Size(96, 15);
            this.lblDateTime.TabIndex = 2;
            this.lblDateTime.Text = "Дата и время:";
            // 
            // lblPersons
            // 
            this.lblPersons.AutoSize = true;
            this.lblPersons.Location = new System.Drawing.Point(14, 108);
            this.lblPersons.Name = "lblPersons";
            this.lblPersons.Size = new System.Drawing.Size(52, 15);
            this.lblPersons.TabIndex = 3;
            this.lblPersons.Text = "Гостей:";
            // 
            // cmbTable
            // 
            this.cmbTable.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTable.FormattingEnabled = true;
            this.cmbTable.Location = new System.Drawing.Point(130, 45);
            this.cmbTable.Name = "cmbTable";
            this.cmbTable.Size = new System.Drawing.Size(250, 23);
            this.cmbTable.TabIndex = 4;
            // 
            // dtpDateTime
            // 
            this.dtpDateTime.CustomFormat = "dd.MM.yyyy HH:mm";
            this.dtpDateTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDateTime.Location = new System.Drawing.Point(130, 74);
            this.dtpDateTime.Name = "dtpDateTime";
            this.dtpDateTime.Size = new System.Drawing.Size(250, 23);
            this.dtpDateTime.TabIndex = 5;
            // 
            // numPersons
            // 
            this.numPersons.Location = new System.Drawing.Point(130, 106);
            this.numPersons.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.numPersons.Name = "numPersons";
            this.numPersons.Size = new System.Drawing.Size(80, 23);
            this.numPersons.TabIndex = 6;
            this.numPersons.Value = new decimal(new int[] { 2, 0, 0, 0 });
            // 
            // grpPreorder
            // 
            this.grpPreorder.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpPreorder.Controls.Add(this.lblTotal);
            this.grpPreorder.Controls.Add(this.gridPreorder);
            this.grpPreorder.Controls.Add(this.btnRemoveDish);
            this.grpPreorder.Controls.Add(this.btnAddDish);
            this.grpPreorder.Controls.Add(this.numQuantity);
            this.grpPreorder.Controls.Add(this.cmbDish);
            this.grpPreorder.Controls.Add(this.lblQuantity);
            this.grpPreorder.Controls.Add(this.lblDish);
            this.grpPreorder.Location = new System.Drawing.Point(12, 140);
            this.grpPreorder.Name = "grpPreorder";
            this.grpPreorder.Size = new System.Drawing.Size(660, 280);
            this.grpPreorder.TabIndex = 7;
            this.grpPreorder.TabStop = false;
            this.grpPreorder.Text = "Предзаказ блюд";
            // 
            // lblDish
            // 
            this.lblDish.AutoSize = true;
            this.lblDish.Location = new System.Drawing.Point(12, 28);
            this.lblDish.Name = "lblDish";
            this.lblDish.Size = new System.Drawing.Size(43, 15);
            this.lblDish.TabIndex = 0;
            this.lblDish.Text = "Блюдо:";
            // 
            // lblQuantity
            // 
            this.lblQuantity.AutoSize = true;
            this.lblQuantity.Location = new System.Drawing.Point(12, 58);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(75, 15);
            this.lblQuantity.TabIndex = 1;
            this.lblQuantity.Text = "Количество:";
            // 
            // cmbDish
            // 
            this.cmbDish.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbDish.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDish.FormattingEnabled = true;
            this.cmbDish.Location = new System.Drawing.Point(118, 25);
            this.cmbDish.Name = "cmbDish";
            this.cmbDish.Size = new System.Drawing.Size(420, 23);
            this.cmbDish.TabIndex = 2;
            // 
            // numQuantity
            // 
            this.numQuantity.Location = new System.Drawing.Point(118, 56);
            this.numQuantity.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.numQuantity.Name = "numQuantity";
            this.numQuantity.Size = new System.Drawing.Size(80, 23);
            this.numQuantity.TabIndex = 3;
            this.numQuantity.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // btnAddDish
            // 
            this.btnAddDish.Location = new System.Drawing.Point(220, 55);
            this.btnAddDish.Name = "btnAddDish";
            this.btnAddDish.Size = new System.Drawing.Size(100, 25);
            this.btnAddDish.TabIndex = 4;
            this.btnAddDish.Text = "Добавить";
            this.btnAddDish.UseVisualStyleBackColor = true;
            this.btnAddDish.Click += new System.EventHandler(this.btnAddDish_Click);
            // 
            // btnRemoveDish
            // 
            this.btnRemoveDish.Location = new System.Drawing.Point(330, 55);
            this.btnRemoveDish.Name = "btnRemoveDish";
            this.btnRemoveDish.Size = new System.Drawing.Size(100, 25);
            this.btnRemoveDish.TabIndex = 5;
            this.btnRemoveDish.Text = "Удалить";
            this.btnRemoveDish.UseVisualStyleBackColor = true;
            this.btnRemoveDish.Click += new System.EventHandler(this.btnRemoveDish_Click);
            // 
            // gridPreorder
            // 
            this.gridPreorder.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridPreorder.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridPreorder.Location = new System.Drawing.Point(15, 90);
            this.gridPreorder.Name = "gridPreorder";
            this.gridPreorder.Size = new System.Drawing.Size(630, 150);
            this.gridPreorder.TabIndex = 6;
            // 
            // lblTotal
            // 
            this.lblTotal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblTotal.Location = new System.Drawing.Point(15, 250);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(176, 20);
            this.lblTotal.TabIndex = 7;
            this.lblTotal.Text = "Итого предзаказа: 0 ₽";
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Location = new System.Drawing.Point(432, 430);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(120, 32);
            this.btnSave.TabIndex = 8;
            this.btnSave.Text = "Сохранить";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(558, 430);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(114, 32);
            this.btnCancel.TabIndex = 9;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // BookingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(684, 474);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.grpPreorder);
            this.Controls.Add(this.numPersons);
            this.Controls.Add(this.dtpDateTime);
            this.Controls.Add(this.cmbTable);
            this.Controls.Add(this.lblPersons);
            this.Controls.Add(this.lblDateTime);
            this.Controls.Add(this.lblTable);
            this.Controls.Add(this.lblTitle);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.MinimumSize = new System.Drawing.Size(700, 513);
            this.Name = "BookingForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Новое бронирование";
            this.Load += new System.EventHandler(this.BookingForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numPersons)).EndInit();
            this.grpPreorder.ResumeLayout(false);
            this.grpPreorder.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numQuantity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridPreorder)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblTable;
        private System.Windows.Forms.Label lblDateTime;
        private System.Windows.Forms.Label lblPersons;
        private System.Windows.Forms.ComboBox cmbTable;
        private System.Windows.Forms.DateTimePicker dtpDateTime;
        private System.Windows.Forms.NumericUpDown numPersons;
        private System.Windows.Forms.GroupBox grpPreorder;
        private System.Windows.Forms.Label lblDish;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.ComboBox cmbDish;
        private System.Windows.Forms.NumericUpDown numQuantity;
        private System.Windows.Forms.Button btnAddDish;
        private System.Windows.Forms.Button btnRemoveDish;
        private System.Windows.Forms.DataGridView gridPreorder;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
    }
}

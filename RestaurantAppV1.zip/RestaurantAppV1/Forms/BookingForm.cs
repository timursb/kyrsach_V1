using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace RestaurantAppV1.Forms
{
    public partial class BookingForm : Form
    {
        private readonly List<PreorderLine> _items = new List<PreorderLine>();
        private DataTable _dishes;

        public BookingForm()
        {
            InitializeComponent();
        }

        private void BookingForm_Load(object sender, EventArgs e)
        {
            try
            {
                ReservationHelper.ValidateSchema();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Проверьте структуру таблиц Reservations и ReservationItems.\r\n\r\n" + ex.Message,
                    "Ошибка базы данных",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                Close();
                return;
            }

            LoadTables();
            LoadDishes();
            dtpDateTime.Value = DateTime.Now.AddHours(2);
            RefreshPreorderGrid();
        }

        private void LoadTables()
        {
            var tables = Db.Query("SELECT TableID, TableNumber, Seats FROM [Tables] ORDER BY TableNumber");
            cmbTable.DisplayMember = "Display";
            cmbTable.ValueMember = "TableID";

            var display = tables.Clone();
            display.Columns.Add("Display", typeof(string));
            foreach (DataRow row in tables.Rows)
            {
                var newRow = display.NewRow();
                newRow["TableID"] = row["TableID"];
                newRow["TableNumber"] = row["TableNumber"];
                newRow["Seats"] = row["Seats"];
                newRow["Display"] = string.Format("Стол {0} ({1} мест)", row["TableNumber"], row["Seats"]);
                display.Rows.Add(newRow);
            }

            cmbTable.DataSource = display;
        }

        private void LoadDishes()
        {
            var columns = Db.GetColumns("Dishes");
            string filter = columns.Contains("IsAvailable") ? " WHERE IsAvailable = True" : string.Empty;

            _dishes = Db.Query("SELECT DishID, [Name], Price FROM Dishes" + filter + " ORDER BY [Name]");

            cmbDish.DisplayMember = "Display";
            cmbDish.ValueMember = "DishID";

            var display = _dishes.Clone();
            display.Columns.Add("Display", typeof(string));
            foreach (DataRow row in _dishes.Rows)
            {
                var newRow = display.NewRow();
                newRow["DishID"] = row["DishID"];
                newRow["Name"] = row["Name"];
                newRow["Price"] = row["Price"];
                newRow["Display"] = string.Format("{0} — {1:N2} ₽", row["Name"], row["Price"]);
                display.Rows.Add(newRow);
            }

            cmbDish.DataSource = display;
        }

        private void btnAddDish_Click(object sender, EventArgs e)
        {
            if (cmbDish.SelectedValue == null)
            {
                return;
            }

            int dishId = Convert.ToInt32(cmbDish.SelectedValue);
            int quantity = (int)numQuantity.Value;
            var dishRow = _dishes.Rows.Cast<DataRow>().First(r => Convert.ToInt32(r["DishID"]) == dishId);
            string dishName = dishRow["Name"].ToString();
            decimal price = Convert.ToDecimal(dishRow["Price"]);

            var existing = _items.FirstOrDefault(i => i.DishId == dishId);
            if (existing != null)
            {
                existing.Quantity += quantity;
            }
            else
            {
                _items.Add(new PreorderLine
                {
                    DishId = dishId,
                    DishName = dishName,
                    Quantity = quantity,
                    Price = price
                });
            }

            RefreshPreorderGrid();
        }

        private void btnRemoveDish_Click(object sender, EventArgs e)
        {
            if (gridPreorder.CurrentRow == null)
            {
                return;
            }

            int index = gridPreorder.CurrentRow.Index;
            if (index >= 0 && index < _items.Count)
            {
                _items.RemoveAt(index);
                RefreshPreorderGrid();
            }
        }

        private void RefreshPreorderGrid()
        {
            var table = new DataTable();
            table.Columns.Add("Блюдо", typeof(string));
            table.Columns.Add("Кол-во", typeof(int));
            table.Columns.Add("Цена", typeof(decimal));
            table.Columns.Add("Сумма", typeof(decimal));

            decimal total = 0;
            foreach (var item in _items)
            {
                table.Rows.Add(item.DishName, item.Quantity, item.Price, item.LineTotal);
                total += item.LineTotal;
            }

            gridPreorder.DataSource = table;
            gridPreorder.ReadOnly = true;
            gridPreorder.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            lblTotal.Text = string.Format("Итого предзаказа: {0:N2} ₽", total);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (CurrentUser.UserId <= 0)
            {
                MessageBox.Show("Для бронирования нужно войти в систему.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cmbTable.SelectedValue == null)
            {
                MessageBox.Show("Выберите стол.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (dtpDateTime.Value <= DateTime.Now)
            {
                MessageBox.Show("Выберите дату и время в будущем.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (numPersons.Value < 1)
            {
                MessageBox.Show("Укажите количество гостей.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                int reservationId = ReservationHelper.CreateReservation(
                    CurrentUser.UserId,
                    Convert.ToInt32(cmbTable.SelectedValue),
                    dtpDateTime.Value,
                    (int)numPersons.Value,
                    _items);

                MessageBox.Show(
                    string.Format("Бронь №{0} успешно создана.\r\nСумма предзаказа: {1:N2} ₽", reservationId, _items.Sum(i => i.LineTotal)),
                    "Готово",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

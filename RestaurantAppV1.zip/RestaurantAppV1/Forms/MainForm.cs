using System;
using System.Windows.Forms;

namespace RestaurantAppV1.Forms
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            ApplyRoleAccess();
        }

        private void ApplyRoleAccess()
        {
            lblWelcome.Text = string.Format("Вы вошли как: {0} ({1})", CurrentUser.FullName, CurrentUser.Role);
            lblTitle.Text = "Ресторан — v2.0";
            lblVersion.Text = CurrentUser.IsAdmin
                ? "Администратор: управление бронированиями"
                : "Клиент: меню, мероприятия, бронирование";

            btnBooking.Visible = !CurrentUser.IsAdmin;
            btnMyReservations.Visible = !CurrentUser.IsAdmin;
            btnAdminReservations.Visible = CurrentUser.IsAdmin;
        }

        private void btnMenu_Click(object sender, EventArgs e)
        {
            using (var form = new MenuForm())
            {
                form.ShowDialog(this);
            }
        }

        private void btnEvents_Click(object sender, EventArgs e)
        {
            using (var form = new EventsForm())
            {
                form.ShowDialog(this);
            }
        }

        private void btnBooking_Click(object sender, EventArgs e)
        {
            using (var form = new BookingForm())
            {
                form.ShowDialog(this);
            }
        }

        private void btnMyReservations_Click(object sender, EventArgs e)
        {
            using (var form = new MyReservationsForm())
            {
                form.ShowDialog(this);
            }
        }

        private void btnAdminReservations_Click(object sender, EventArgs e)
        {
            using (var form = new AdminReservationsForm())
            {
                form.ShowDialog(this);
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            CurrentUser.Clear();
            Close();
        }
    }
}

namespace RestaurantAppV1.Forms
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.btnMenu = new System.Windows.Forms.Button();
            this.btnEvents = new System.Windows.Forms.Button();
            this.btnBooking = new System.Windows.Forms.Button();
            this.btnMyReservations = new System.Windows.Forms.Button();
            this.btnAdminReservations = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.lblVersion = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(72, 20);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(256, 32);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Ресторан — v2.0";
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Location = new System.Drawing.Point(40, 62);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(120, 15);
            this.lblWelcome.TabIndex = 1;
            this.lblWelcome.Text = "Вы вошли как: ...";
            // 
            // btnMenu
            // 
            this.btnMenu.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.btnMenu.Location = new System.Drawing.Point(78, 95);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(244, 42);
            this.btnMenu.TabIndex = 2;
            this.btnMenu.Text = "Меню";
            this.btnMenu.UseVisualStyleBackColor = true;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // btnEvents
            // 
            this.btnEvents.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.btnEvents.Location = new System.Drawing.Point(78, 145);
            this.btnEvents.Name = "btnEvents";
            this.btnEvents.Size = new System.Drawing.Size(244, 42);
            this.btnEvents.TabIndex = 3;
            this.btnEvents.Text = "Мероприятия";
            this.btnEvents.UseVisualStyleBackColor = true;
            this.btnEvents.Click += new System.EventHandler(this.btnEvents_Click);
            // 
            // btnBooking
            // 
            this.btnBooking.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.btnBooking.Location = new System.Drawing.Point(78, 195);
            this.btnBooking.Name = "btnBooking";
            this.btnBooking.Size = new System.Drawing.Size(244, 42);
            this.btnBooking.TabIndex = 4;
            this.btnBooking.Text = "Забронировать стол";
            this.btnBooking.UseVisualStyleBackColor = true;
            this.btnBooking.Click += new System.EventHandler(this.btnBooking_Click);
            // 
            // btnMyReservations
            // 
            this.btnMyReservations.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.btnMyReservations.Location = new System.Drawing.Point(78, 245);
            this.btnMyReservations.Name = "btnMyReservations";
            this.btnMyReservations.Size = new System.Drawing.Size(244, 42);
            this.btnMyReservations.TabIndex = 5;
            this.btnMyReservations.Text = "Мои бронирования";
            this.btnMyReservations.UseVisualStyleBackColor = true;
            this.btnMyReservations.Click += new System.EventHandler(this.btnMyReservations_Click);
            // 
            // btnAdminReservations
            // 
            this.btnAdminReservations.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.btnAdminReservations.Location = new System.Drawing.Point(78, 195);
            this.btnAdminReservations.Name = "btnAdminReservations";
            this.btnAdminReservations.Size = new System.Drawing.Size(244, 42);
            this.btnAdminReservations.TabIndex = 6;
            this.btnAdminReservations.Text = "Управление бронированиями";
            this.btnAdminReservations.UseVisualStyleBackColor = true;
            this.btnAdminReservations.Click += new System.EventHandler(this.btnAdminReservations_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(78, 305);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(244, 32);
            this.btnLogout.TabIndex = 7;
            this.btnLogout.Text = "Выйти";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // lblVersion
            // 
            this.lblVersion.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lblVersion.Location = new System.Drawing.Point(40, 345);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(320, 30);
            this.lblVersion.TabIndex = 8;
            this.lblVersion.Text = "Описание роли";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 385);
            this.Controls.Add(this.lblVersion);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.btnAdminReservations);
            this.Controls.Add(this.btnMyReservations);
            this.Controls.Add(this.btnBooking);
            this.Controls.Add(this.btnEvents);
            this.Controls.Add(this.btnMenu);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.lblTitle);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ресторан";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Button btnMenu;
        private System.Windows.Forms.Button btnEvents;
        private System.Windows.Forms.Button btnBooking;
        private System.Windows.Forms.Button btnMyReservations;
        private System.Windows.Forms.Button btnAdminReservations;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Label lblVersion;
    }
}

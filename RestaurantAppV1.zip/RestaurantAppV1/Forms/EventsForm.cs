using System;
using System.Data;
using System.Windows.Forms;

namespace RestaurantAppV1.Forms
{
    public partial class EventsForm : Form
    {
        public EventsForm()
        {
            InitializeComponent();
        }

        private void EventsForm_Load(object sender, EventArgs e)
        {
            LoadEvents();
        }

        private void chkUpcomingOnly_CheckedChanged(object sender, EventArgs e)
        {
            LoadEvents();
        }

        private void LoadEvents()
        {
            try
            {
                string sql = chkUpcomingOnly.Checked
                    ? "SELECT EventID, [Title] AS [Название], [Description] AS [Описание], EventDateTime AS [Дата и время] FROM Events WHERE EventDateTime >= Date() ORDER BY EventDateTime"
                    : "SELECT EventID, [Title] AS [Название], [Description] AS [Описание], EventDateTime AS [Дата и время] FROM Events ORDER BY EventDateTime";

                dataGridViewEvents.DataSource = Db.Query(sql);
                ConfigureGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Не удалось загрузить мероприятия.\r\n\r\n" + ex.Message,
                    "Ошибка",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void ConfigureGrid()
        {
            if (dataGridViewEvents.Columns.Contains("EventID"))
            {
                dataGridViewEvents.Columns["EventID"].Visible = false;
            }

            if (dataGridViewEvents.Columns.Contains("Дата и время"))
            {
                dataGridViewEvents.Columns["Дата и время"].DefaultCellStyle.Format = "dd.MM.yyyy HH:mm";
            }

            dataGridViewEvents.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewEvents.ReadOnly = true;
            dataGridViewEvents.AllowUserToAddRows = false;
            dataGridViewEvents.AllowUserToDeleteRows = false;
            dataGridViewEvents.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }
    }
}

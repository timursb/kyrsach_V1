using System;
using System.Windows.Forms;

namespace RestaurantAppV1.Forms
{
    public partial class RegisterForm : Form
    {
        public RegisterForm()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!AuthService.TryRegister(
                txtLogin.Text,
                txtPassword.Text,
                txtConfirmPassword.Text,
                txtFullName.Text,
                txtPhone.Text,
                txtEmail.Text,
                txtComment.Text,
                out var error))
            {
                MessageBox.Show(error, "Регистрация", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            MessageBox.Show(
                "Регистрация успешна. Теперь войдите в систему.",
                "Регистрация",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);

            DialogResult = DialogResult.OK;
            Close();
        }
    }
}

using System;
using System.Data;
using System.Windows.Forms;

namespace RestaurantAppV1.Forms
{
    public partial class MyReservationsForm : Form
    {
        public MyReservationsForm()
        {
            InitializeComponent();
        }

        private void MyReservationsForm_Load(object sender, EventArgs e)
        {
            LoadReservations();
        }

        private void LoadReservations()
        {
            if (CurrentUser.UserId <= 0)
            {
                return;
            }

            try
            {
                gridReservations.DataSource = ReservationHelper.GetUserReservations(CurrentUser.UserId);
                ConfigureGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось загрузить бронирования.\r\n\r\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ConfigureGrid()
        {
            if (gridReservations.Columns.Contains("ReservationID"))
            {
                gridReservations.Columns["ReservationID"].Visible = false;
            }

            if (gridReservations.Columns.Contains("Сумма предзаказа"))
            {
                gridReservations.Columns["Сумма предзаказа"].DefaultCellStyle.Format = "N2";
            }

            if (gridReservations.Columns.Contains("Дата и время"))
            {
                gridReservations.Columns["Дата и время"].DefaultCellStyle.Format = "dd.MM.yyyy HH:mm";
            }

            gridReservations.ReadOnly = true;
            gridReservations.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            gridReservations.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private int? GetSelectedReservationId()
        {
            if (gridReservations.CurrentRow == null)
            {
                return null;
            }

            return Convert.ToInt32(gridReservations.CurrentRow.Cells["ReservationID"].Value);
        }

        private void btnDetails_Click(object sender, EventArgs e)
        {
            var reservationId = GetSelectedReservationId();
            if (!reservationId.HasValue)
            {
                MessageBox.Show("Выберите бронирование.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var items = ReservationHelper.GetReservationItems(reservationId.Value);
            gridItems.DataSource = items;
            gridItems.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            gridItems.ReadOnly = true;

            decimal total = ReservationHelper.GetReservationTotal(reservationId.Value);
            lblItemsTotal.Text = string.Format("Сумма предзаказа: {0:N2} ₽", total);
        }

        private void btnCancelReservation_Click(object sender, EventArgs e)
        {
            var reservationId = GetSelectedReservationId();
            if (!reservationId.HasValue)
            {
                MessageBox.Show("Выберите бронирование.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var status = gridReservations.CurrentRow.Cells["Статус"].Value.ToString();
            if (status == "Отменена")
            {
                MessageBox.Show("Бронь уже отменена.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (MessageBox.Show("Отменить выбранное бронирование?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            {
                return;
            }

            try
            {
                ReservationHelper.UpdateStatus(reservationId.Value, "Отменена");
                LoadReservations();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось отменить бронь.\r\n\r\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

using System;
using System.Windows.Forms;

namespace RestaurantAppV1.Forms
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (!AuthService.TryLogin(txtLogin.Text, txtPassword.Text, out var error))
            {
                MessageBox.Show(error, "Вход", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult = DialogResult.OK;
            Close();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            using (var form = new RegisterForm())
            {
                form.ShowDialog(this);
            }
        }
    }
}

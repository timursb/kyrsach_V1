namespace RestaurantAppV1.Forms
{
    partial class MyReservationsForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.gridReservations = new System.Windows.Forms.DataGridView();
            this.btnDetails = new System.Windows.Forms.Button();
            this.btnCancelReservation = new System.Windows.Forms.Button();
            this.lblItems = new System.Windows.Forms.Label();
            this.gridItems = new System.Windows.Forms.DataGridView();
            this.lblItemsTotal = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.gridReservations)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridItems)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(12, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(168, 25);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Мои бронирования";
            // 
            // gridReservations
            // 
            this.gridReservations.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridReservations.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridReservations.Location = new System.Drawing.Point(12, 45);
            this.gridReservations.Name = "gridReservations";
            this.gridReservations.Size = new System.Drawing.Size(760, 200);
            this.gridReservations.TabIndex = 1;
            // 
            // btnDetails
            // 
            this.btnDetails.Location = new System.Drawing.Point(12, 251);
            this.btnDetails.Name = "btnDetails";
            this.btnDetails.Size = new System.Drawing.Size(150, 30);
            this.btnDetails.TabIndex = 2;
            this.btnDetails.Text = "Состав предзаказа";
            this.btnDetails.UseVisualStyleBackColor = true;
            this.btnDetails.Click += new System.EventHandler(this.btnDetails_Click);
            // 
            // btnCancelReservation
            // 
            this.btnCancelReservation.Location = new System.Drawing.Point(168, 251);
            this.btnCancelReservation.Name = "btnCancelReservation";
            this.btnCancelReservation.Size = new System.Drawing.Size(150, 30);
            this.btnCancelReservation.TabIndex = 3;
            this.btnCancelReservation.Text = "Отменить бронь";
            this.btnCancelReservation.UseVisualStyleBackColor = true;
            this.btnCancelReservation.Click += new System.EventHandler(this.btnCancelReservation_Click);
            // 
            // lblItems
            // 
            this.lblItems.AutoSize = true;
            this.lblItems.Location = new System.Drawing.Point(12, 295);
            this.lblItems.Name = "lblItems";
            this.lblItems.Size = new System.Drawing.Size(109, 15);
            this.lblItems.TabIndex = 4;
            this.lblItems.Text = "Позиции предзаказа";
            // 
            // gridItems
            // 
            this.gridItems.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gridItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridItems.Location = new System.Drawing.Point(12, 313);
            this.gridItems.Name = "gridItems";
            this.gridItems.Size = new System.Drawing.Size(760, 150);
            this.gridItems.TabIndex = 5;
            // 
            // lblItemsTotal
            // 
            this.lblItemsTotal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblItemsTotal.AutoSize = true;
            this.lblItemsTotal.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblItemsTotal.Location = new System.Drawing.Point(12, 473);
            this.lblItemsTotal.Name = "lblItemsTotal";
            this.lblItemsTotal.Size = new System.Drawing.Size(164, 19);
            this.lblItemsTotal.TabIndex = 6;
            this.lblItemsTotal.Text = "Сумма предзаказа: 0 ₽";
            // 
            // MyReservationsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 501);
            this.Controls.Add(this.lblItemsTotal);
            this.Controls.Add(this.gridItems);
            this.Controls.Add(this.lblItems);
            this.Controls.Add(this.btnCancelReservation);
            this.Controls.Add(this.btnDetails);
            this.Controls.Add(this.gridReservations);
            this.Controls.Add(this.lblTitle);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.MinimumSize = new System.Drawing.Size(800, 540);
            this.Name = "MyReservationsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Мои бронирования";
            this.Load += new System.EventHandler(this.MyReservationsForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridReservations)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridItems)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.DataGridView gridReservations;
        private System.Windows.Forms.Button btnDetails;
        private System.Windows.Forms.Button btnCancelReservation;
        private System.Windows.Forms.Label lblItems;
        private System.Windows.Forms.DataGridView gridItems;
        private System.Windows.Forms.Label lblItemsTotal;
    }
}

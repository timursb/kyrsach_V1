namespace RestaurantAppV1.Forms
{
    partial class EventsForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dataGridViewEvents = new System.Windows.Forms.DataGridView();
            this.chkUpcomingOnly = new System.Windows.Forms.CheckBox();
            this.lblTitle = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEvents)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewEvents
            // 
            this.dataGridViewEvents.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewEvents.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewEvents.Location = new System.Drawing.Point(12, 72);
            this.dataGridViewEvents.Name = "dataGridViewEvents";
            this.dataGridViewEvents.Size = new System.Drawing.Size(760, 377);
            this.dataGridViewEvents.TabIndex = 0;
            // 
            // chkUpcomingOnly
            // 
            this.chkUpcomingOnly.AutoSize = true;
            this.chkUpcomingOnly.Checked = true;
            this.chkUpcomingOnly.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkUpcomingOnly.Location = new System.Drawing.Point(12, 47);
            this.chkUpcomingOnly.Name = "chkUpcomingOnly";
            this.chkUpcomingOnly.Size = new System.Drawing.Size(198, 19);
            this.chkUpcomingOnly.TabIndex = 1;
            this.chkUpcomingOnly.Text = "Только предстоящие события";
            this.chkUpcomingOnly.UseVisualStyleBackColor = true;
            this.chkUpcomingOnly.CheckedChanged += new System.EventHandler(this.chkUpcomingOnly_CheckedChanged);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(12, 12);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(132, 25);
            this.lblTitle.TabIndex = 2;
            this.lblTitle.Text = "Мероприятия";
            // 
            // EventsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 461);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.chkUpcomingOnly);
            this.Controls.Add(this.dataGridViewEvents);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.MinimumSize = new System.Drawing.Size(600, 400);
            this.Name = "EventsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Мероприятия ресторана";
            this.Load += new System.EventHandler(this.EventsForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEvents)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.DataGridView dataGridViewEvents;
        private System.Windows.Forms.CheckBox chkUpcomingOnly;
        private System.Windows.Forms.Label lblTitle;
    }
}

namespace RestaurantAppV1.Forms
{
    partial class MenuForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dataGridViewMenu = new System.Windows.Forms.DataGridView();
            this.chkAvailableOnly = new System.Windows.Forms.CheckBox();
            this.lblTitle = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMenu)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewMenu
            // 
            this.dataGridViewMenu.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewMenu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewMenu.Location = new System.Drawing.Point(12, 72);
            this.dataGridViewMenu.Name = "dataGridViewMenu";
            this.dataGridViewMenu.Size = new System.Drawing.Size(760, 377);
            this.dataGridViewMenu.TabIndex = 0;
            // 
            // chkAvailableOnly
            // 
            this.chkAvailableOnly.AutoSize = true;
            this.chkAvailableOnly.Checked = true;
            this.chkAvailableOnly.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkAvailableOnly.Location = new System.Drawing.Point(12, 47);
            this.chkAvailableOnly.Name = "chkAvailableOnly";
            this.chkAvailableOnly.Size = new System.Drawing.Size(170, 19);
            this.chkAvailableOnly.TabIndex = 1;
            this.chkAvailableOnly.Text = "Только доступные блюда";
            this.chkAvailableOnly.UseVisualStyleBackColor = true;
            this.chkAvailableOnly.CheckedChanged += new System.EventHandler(this.chkAvailableOnly_CheckedChanged);
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(12, 12);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(63, 25);
            this.lblTitle.TabIndex = 2;
            this.lblTitle.Text = "Меню";
            // 
            // MenuForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 461);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.chkAvailableOnly);
            this.Controls.Add(this.dataGridViewMenu);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.MinimumSize = new System.Drawing.Size(600, 400);
            this.Name = "MenuForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Меню ресторана";
            this.Load += new System.EventHandler(this.MenuForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMenu)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.DataGridView dataGridViewMenu;
        private System.Windows.Forms.CheckBox chkAvailableOnly;
        private System.Windows.Forms.Label lblTitle;
    }
}

using System;
using System.Data;
using System.Windows.Forms;

namespace RestaurantAppV1.Forms
{
    public partial class AdminReservationsForm : Form
    {
        public AdminReservationsForm()
        {
            InitializeComponent();
        }

        private void AdminReservationsForm_Load(object sender, EventArgs e)
        {
            cmbStatus.Items.AddRange(new object[] { "Новая", "Подтверждена", "Отменена" });
            LoadReservations();
        }

        private void LoadReservations()
        {
            try
            {
                gridReservations.DataSource = ReservationHelper.GetAllReservations();
                ConfigureGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось загрузить бронирования.\r\n\r\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ConfigureGrid()
        {
            if (gridReservations.Columns.Contains("ReservationID"))
            {
                gridReservations.Columns["ReservationID"].Visible = false;
            }

            if (gridReservations.Columns.Contains("Сумма предзаказа"))
            {
                gridReservations.Columns["Сумма предзаказа"].DefaultCellStyle.Format = "N2";
            }

            if (gridReservations.Columns.Contains("Дата и время"))
            {
                gridReservations.Columns["Дата и время"].DefaultCellStyle.Format = "dd.MM.yyyy HH:mm";
            }

            gridReservations.ReadOnly = true;
            gridReservations.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            gridReservations.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private int? GetSelectedReservationId()
        {
            if (gridReservations.CurrentRow == null)
            {
                return null;
            }

            return Convert.ToInt32(gridReservations.CurrentRow.Cells["ReservationID"].Value);
        }

        private void btnDetails_Click(object sender, EventArgs e)
        {
            var reservationId = GetSelectedReservationId();
            if (!reservationId.HasValue)
            {
                MessageBox.Show("Выберите бронирование.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var items = ReservationHelper.GetReservationItems(reservationId.Value);
            gridItems.DataSource = items;
            gridItems.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            gridItems.ReadOnly = true;

            decimal total = ReservationHelper.GetReservationTotal(reservationId.Value);
            lblItemsTotal.Text = string.Format("Сумма предзаказа: {0:N2} ₽", total);
        }

        private void btnUpdateStatus_Click(object sender, EventArgs e)
        {
            var reservationId = GetSelectedReservationId();
            if (!reservationId.HasValue)
            {
                MessageBox.Show("Выберите бронирование.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (cmbStatus.SelectedItem == null)
            {
                MessageBox.Show("Выберите новый статус.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                ReservationHelper.UpdateStatus(reservationId.Value, cmbStatus.SelectedItem.ToString());
                LoadReservations();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось обновить статус.\r\n\r\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var reservationId = GetSelectedReservationId();
            if (!reservationId.HasValue)
            {
                MessageBox.Show("Выберите бронирование.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (MessageBox.Show(
                "Удалить выбранное бронирование вместе с предзаказом?",
                "Подтверждение",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning) != DialogResult.Yes)
            {
                return;
            }

            try
            {
                ReservationHelper.DeleteReservation(reservationId.Value);
                gridItems.DataSource = null;
                lblItemsTotal.Text = "Сумма предзаказа: 0 ₽";
                LoadReservations();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось удалить бронь.\r\n\r\n" + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadReservations();
        }
    }
}

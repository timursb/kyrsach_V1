using System;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RestaurantAppV1.Forms
{
    public partial class MenuForm : Form
    {
        private string _availableColumn;

        public MenuForm()
        {
            InitializeComponent();
        }

        private void MenuForm_Load(object sender, EventArgs e)
        {
            ConfigureAvailabilityFilter();
            LoadMenu();
        }

        private void chkAvailableOnly_CheckedChanged(object sender, EventArgs e)
        {
            LoadMenu();
        }

        private void ConfigureAvailabilityFilter()
        {
            var columns = Db.GetColumns("Dishes");
            _availableColumn = Db.ResolveColumn(columns, "IsAvailable", "Available", "Доступно");

            if (_availableColumn == null)
            {
                chkAvailableOnly.Enabled = false;
                chkAvailableOnly.Checked = false;
            }
        }

        private void LoadMenu()
        {
            try
            {
                var columns = Db.GetColumns("Dishes");
                var nameColumn = Db.ResolveColumn(columns, "Name", "DishName", "Title", "Название");
                var descriptionColumn = Db.ResolveColumn(columns, "Description", "Описание");
                var priceColumn = Db.ResolveColumn(columns, "Price", "Cost", "Цена");

                if (nameColumn == null || priceColumn == null)
                {
                    throw new InvalidOperationException(
                        "В таблице Dishes не найдены обязательные поля.\r\n" +
                        "Нужны: Name (или DishName/Title) и Price.\r\n\r\n" +
                        "Найденные поля: " + string.Join(", ", columns.OrderBy(c => c)));
                }

                var sql = new StringBuilder();
                sql.Append("SELECT DishID, ");
                sql.Append(nameColumn).Append(" AS [Название], ");

                if (descriptionColumn != null)
                {
                    sql.Append(descriptionColumn).Append(" AS [Описание], ");
                }
                else
                {
                    sql.Append("'' AS [Описание], ");
                }

                sql.Append(priceColumn).Append(" AS [Цена]");

                if (_availableColumn != null)
                {
                    sql.Append(", ").Append(_availableColumn).Append(" AS [Доступно]");
                }

                sql.Append(" FROM Dishes");

                if (_availableColumn != null && chkAvailableOnly.Checked)
                {
                    sql.Append(" WHERE ").Append(_availableColumn).Append(" = True");
                }

                sql.Append(" ORDER BY ").Append(nameColumn);

                dataGridViewMenu.DataSource = Db.Query(sql.ToString());
                ConfigureGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Не удалось загрузить меню.\r\n\r\n" + ex.Message,
                    "Ошибка",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void ConfigureGrid()
        {
            if (dataGridViewMenu.Columns.Contains("DishID"))
            {
                dataGridViewMenu.Columns["DishID"].Visible = false;
            }

            if (dataGridViewMenu.Columns.Contains("Цена"))
            {
                dataGridViewMenu.Columns["Цена"].DefaultCellStyle.Format = "N2";
            }

            dataGridViewMenu.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewMenu.ReadOnly = true;
            dataGridViewMenu.AllowUserToAddRows = false;
            dataGridViewMenu.AllowUserToDeleteRows = false;
            dataGridViewMenu.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }
    }
}

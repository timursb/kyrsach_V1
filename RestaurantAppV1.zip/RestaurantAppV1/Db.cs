using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;

namespace RestaurantAppV1
{
    public static class Db
    {
        public static readonly string ConnectionString =
            ConfigurationManager.ConnectionStrings["RestaurantDb"].ConnectionString;

        public static DataTable Query(string sql, params OleDbParameter[] parameters)
        {
            using (var connection = new OleDbConnection(ConnectionString))
            using (var command = new OleDbCommand(sql, connection))
            using (var adapter = new OleDbDataAdapter(command))
            {
                if (parameters != null && parameters.Length > 0)
                {
                    command.Parameters.AddRange(parameters);
                }

                var table = new DataTable();
                adapter.Fill(table);
                return table;
            }
        }

        public static int Execute(string sql, params OleDbParameter[] parameters)
        {
            using (var connection = new OleDbConnection(ConnectionString))
            using (var command = new OleDbCommand(sql, connection))
            {
                if (parameters != null && parameters.Length > 0)
                {
                    command.Parameters.AddRange(parameters);
                }

                connection.Open();
                return command.ExecuteNonQuery();
            }
        }

        public static object Scalar(string sql, params OleDbParameter[] parameters)
        {
            using (var connection = new OleDbConnection(ConnectionString))
            using (var command = new OleDbCommand(sql, connection))
            {
                if (parameters != null && parameters.Length > 0)
                {
                    command.Parameters.AddRange(parameters);
                }

                connection.Open();
                return command.ExecuteScalar();
            }
        }

        public static HashSet<string> GetColumns(string tableName)
        {
            using (var connection = new OleDbConnection(ConnectionString))
            {
                connection.Open();
                var schema = connection.GetOleDbSchemaTable(
                    OleDbSchemaGuid.Columns,
                    new object[] { null, null, tableName, null });

                var columns = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (DataRow row in schema.Rows)
                {
                    columns.Add(row["COLUMN_NAME"].ToString());
                }

                return columns;
            }
        }

        public static string ResolveColumn(HashSet<string> columns, params string[] candidates)
        {
            foreach (var candidate in candidates)
            {
                if (columns.Contains(candidate))
                {
                    return Bracket(candidate);
                }
            }

            return null;
        }

        public static string Bracket(string columnName)
        {
            return "[" + columnName.Replace("]", "]]") + "]";
        }
    }
}
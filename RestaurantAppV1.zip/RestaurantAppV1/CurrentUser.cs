namespace RestaurantAppV1
{
    public static class CurrentUser
    {
        public static int UserId { get; private set; }
        public static string Login { get; private set; }
        public static string FullName { get; private set; }
        public static string Role { get; private set; }

        public static bool IsAdmin => Role == "Admin";
        public static bool IsLoggedIn => UserId > 0;

        public static void Set(int userId, string login, string fullName, string role)
        {
            UserId = userId;
            Login = login;
            FullName = fullName;
            Role = role;
        }

        public static void Clear()
        {
            UserId = 0;
            Login = null;
            FullName = null;
            Role = null;
        }
    }
}

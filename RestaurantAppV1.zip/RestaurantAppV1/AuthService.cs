using System;
using System.Data.OleDb;

namespace RestaurantAppV1
{
    public static class AuthService
    {
        public static bool TryLogin(string login, string password, out string errorMessage)
        {
            errorMessage = null;

            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
            {
                errorMessage = "Введите логин и пароль.";
                return false;
            }

            try
            {
                var table = Db.Query(
                    "SELECT UserID, Login, FullName, [Role] FROM Users WHERE Login = ? AND [Password] = ?",
                    new OleDbParameter { OleDbType = OleDbType.VarWChar, Value = login.Trim() },
                    new OleDbParameter { OleDbType = OleDbType.VarWChar, Value = password });

                if (table.Rows.Count == 0)
                {
                    errorMessage = "Неверный логин или пароль.";
                    return false;
                }

                var row = table.Rows[0];
                CurrentUser.Set(
                    Convert.ToInt32(row["UserID"]),
                    row["Login"].ToString(),
                    row["FullName"] == DBNull.Value ? row["Login"].ToString() : row["FullName"].ToString(),
                    row["Role"].ToString());

                return true;
            }
            catch (Exception ex)
            {
                errorMessage = "Ошибка входа: " + ex.Message;
                return false;
            }
        }

        public static bool TryRegister(
            string login,
            string password,
            string confirmPassword,
            string fullName,
            string phone,
            string email,
            string comment,
            out string errorMessage)
        {
            errorMessage = null;

            if (string.IsNullOrWhiteSpace(login))
            {
                errorMessage = "Введите логин.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(password))
            {
                errorMessage = "Введите пароль.";
                return false;
            }

            if (password != confirmPassword)
            {
                errorMessage = "Пароли не совпадают.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(fullName))
            {
                errorMessage = "Введите ФИО.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(phone))
            {
                errorMessage = "Введите телефон.";
                return false;
            }

            try
            {
                var exists = Db.Query(
                    "SELECT UserID FROM Users WHERE Login = ?",
                    new OleDbParameter { OleDbType = OleDbType.VarWChar, Value = login.Trim() });

                if (exists.Rows.Count > 0)
                {
                    errorMessage = "Пользователь с таким логином уже существует.";
                    return false;
                }

                Db.Execute(
                    "INSERT INTO Users (Login, [Password], [Role], FullName, Phone, Email, Comment) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    new OleDbParameter { OleDbType = OleDbType.VarWChar, Value = login.Trim() },
                    new OleDbParameter { OleDbType = OleDbType.VarWChar, Value = password },
                    new OleDbParameter { OleDbType = OleDbType.VarWChar, Value = "User" },
                    new OleDbParameter { OleDbType = OleDbType.VarWChar, Value = fullName.Trim() },
                    new OleDbParameter { OleDbType = OleDbType.VarWChar, Value = phone.Trim() },
                    new OleDbParameter { OleDbType = OleDbType.VarWChar, Value = string.IsNullOrWhiteSpace(email) ? (object)DBNull.Value : email.Trim() },
                    new OleDbParameter { OleDbType = OleDbType.LongVarWChar, Value = string.IsNullOrWhiteSpace(comment) ? (object)DBNull.Value : comment.Trim() });

                return true;
            }
            catch (Exception ex)
            {
                errorMessage = "Ошибка регистрации: " + ex.Message;
                return false;
            }
        }
    }
}

using System;
using System.Windows.Forms;
using RestaurantAppV1.Forms;

namespace RestaurantAppV1
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            AppDomain.CurrentDomain.SetData("DataDirectory", Application.StartupPath);

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            while (true)
            {
                using (var loginForm = new LoginForm())
                {
                    if (loginForm.ShowDialog() != DialogResult.OK)
                    {
                        return;
                    }
                }

                using (var mainForm = new MainForm())
                {
                    mainForm.ShowDialog();
                }

                CurrentUser.Clear();
            }
        }
    }
}
